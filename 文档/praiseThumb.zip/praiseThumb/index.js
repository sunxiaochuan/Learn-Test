window.add=function(num){
return num+1;
}