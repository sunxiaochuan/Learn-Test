import Thumb from 'index.js'

let f= new Thumb(0,$('#thumb'));
f.clickAction();